@extends('master')

@section('title', 'Home')

@section('content')

    <div class="row">
        <div class="col-lg-12">
            <div class="jumbotron">
                <h1> Laravel 4 Framework </h1>
                <p class="lead">This is a template for a simple marketing or informational website. It includes a large callout called a jumbotron and three supporting pieces of content.
                 Use it as a starting point to create something more unique. </p>
                <p><a class="btn btn-lg btn-success" href="#" role="button">Lean more.</a></p>
            </div>
        </div>
    </div>

  

@stop



    
    
