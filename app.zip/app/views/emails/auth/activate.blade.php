<h2><strong style="font-size: 14px; line-height: 14px; font-family: 'Lucida Sans Unicode', Verdana, Arial, sans-serif; color: rgb(0, 0, 0);">Hello, <?php echo $name?>&nbsp;</strong><br style="color: rgb(34, 34, 34); font-family: arial, sans-serif; font-size: 14px; line-height: 14px;" />
<span style="color: rgb(34, 34, 34); font-family: arial, sans-serif; font-size: 14px; line-height: 14px;">&nbsp;</span></h2>

<p style="font-size: 14px; line-height: 14px; font-family: 'Lucida Sans Unicode', Verdana, Arial, sans-serif; color: rgb(0, 0, 0);"><strong>We would like to thank you for having created a Rain account.</strong></p>

<hr />
<p><span style="color: rgb(240, 66, 26); font-family: 'Lucida Sans Unicode', Verdana, Arial, sans-serif; font-size: 12px; font-weight: bold; line-height: 12px;">Warning! These details are private and confidential! Make sure you never share them with anyone...</span></p>

<p><span style="line-height: 12px; font-family: 'Lucida Sans Unicode', Verdana, Arial, sans-serif; color: rgb(0, 0, 0); font-size: 12px; font-weight: bold;">Login name :&nbsp;</span><span style="line-height: 12px; font-family: 'Lucida Sans Unicode', Verdana, Arial, sans-serif; color: rgb(0, 0, 0); font-size: 12px;"><?php echo $email?></span><br style="color: rgb(34, 34, 34); font-family: arial, sans-serif; font-size: 14px; line-height: 12px;" />
<span style="line-height: 12px; font-family: 'Lucida Sans Unicode', Verdana, Arial, sans-serif; color: rgb(0, 0, 0); font-size: 12px; font-weight: bold;">Password :&nbsp;</span><span style="line-height: 12px; font-family: 'Lucida Sans Unicode', Verdana, Arial, sans-serif; color: rgb(0, 0, 0); font-size: 12px;"><?php echo $password?></span><br style="color: rgb(34, 34, 34); font-family: arial, sans-serif; font-size: 14px; line-height: 12px;" />
<span style="color: rgb(34, 34, 34); font-family: arial, sans-serif; font-size: 14px; line-height: 12px;">&nbsp;</span></p>

<p><span style="color: rgb(34, 34, 34); font-family: arial, sans-serif; font-size: 14px; line-height: 12px;"><a href="http://raindb.dev/login"><img alt="" src="https://lh3.googleusercontent.com/-rSbM0Plo4Fo/U9HnJCO1HfI/AAAAAAAAAXs/qqGI37GSV-s/w292-h53-no/register.png" /></a></span></p>

<p>&nbsp;</p>

<p>&nbsp;</p>




